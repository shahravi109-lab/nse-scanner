# NSE IPO Daily Scanner — Setup Guide

Runs every night at **10 PM IST (Mon–Fri)** via GitHub Actions (free).
Sends matching stocks to your **Telegram** with GTT order details.

---

## Your Exact Criteria

| Filter | Value |
|---|---|
| Listed within | 365 days |
| Market Cap | Rs.1,000 Cr – Rs.50,000 Cr |
| Price below 52W High | 0% to 6% |
| Pattern | Insider Bar on Daily Chart |
| Entry | Mother candle High + Rs.0.10 |
| Stop Loss | Mother candle Low – Rs.0.10 |
| Target | 1:2 Risk:Reward |

---

## Setup Steps (~15 minutes, all free)

### STEP 1 — Create Telegram Bot

1. Open Telegram → search **@BotFather**
2. Send: `/newbot`
3. Name it: `NSE IPO Scanner`
4. Username: `nse_ipo_yourname_bot`
5. Copy the **Bot Token** (looks like `7123456789:AAFxxx...`)
6. Send any message to your new bot (required before it can message you)
7. Open this URL in browser (replace YOUR_TOKEN):
   ```
   https://api.telegram.org/botYOUR_TOKEN/getUpdates
   ```
8. Find `"id":` inside `"chat":{` → that number is your **Chat ID**

---

### STEP 2 — Create GitHub Repository

1. Go to [github.com](https://github.com) → sign up free if needed
2. Click **+** → **New repository**
3. Name: `nse-scanner` → **Public** → **Create repository**
4. Upload all 4 files from this ZIP:
   - `scanner.py`
   - `requirements.txt`
   - `.github/workflows/daily_scan.yml`
   - `README.md`
   
   (On the repo page click **"uploading an existing file"**)
   
   **Important:** The `.github/workflows/` folder structure must be preserved exactly.

---

### STEP 3 — Add Telegram Secrets

1. In your GitHub repo → **Settings** tab
2. Left sidebar → **Secrets and variables** → **Actions**
3. Click **New repository secret** — add these two:

   | Name | Value |
   |---|---|
   | `TELEGRAM_BOT_TOKEN` | Your token from Step 1 |
   | `TELEGRAM_CHAT_ID` | Your chat ID from Step 1 |

---

### STEP 4 — Test Right Now

1. Go to repo → **Actions** tab
2. Click **NSE IPO Daily Scanner** on the left
3. Click **Run workflow** button (top right) → **Run workflow**
4. Watch it run (takes 2–4 minutes)
5. Check Telegram for your first scan result!

---

## Sample Telegram Message

```
NSE IPO Daily Scanner
14 May 2025  10:00 PM
──────────────────────────────
Checked : 51 stocks
Passed filters 1-3 : 8
Insider bars found : 2
──────────────────────────────

NETWEB  |  Netweb Technologies India
Listed : 22-Jul-2023  (296d ago)
Mkt Cap : Rs.4,820 Cr
Price : Rs.2,340  |  52W High : Rs.2,450  (4.5% below)

Candles:
  Mother  [13-May]  H: 2,380  L: 2,290
  Insider [14-May]  H: 2,355  L: 2,310

GTT Order:
  Entry      : Rs.2,380.10   (mother H + 0.10)
  Stop Loss  : Rs.2,289.90   (mother L - 0.10)
  Target     : Rs.2,560.30   (1:2 R:R)
  Risk/share : Rs.90.20
──────────────────────────────
```

---

## Customise the Scanner

Open `scanner.py` and edit the settings at the top:

```python
MAX_PCT_BELOW_HIGH = 6.0      # Change to 3.0 for stricter filter
MIN_MARKET_CAP_CR  = 1_000    # Minimum market cap in Crores
MAX_MARKET_CAP_CR  = 50_000   # Maximum market cap in Crores
MAX_LISTING_DAYS   = 365      # Days since IPO listing
ENTRY_BUFFER       = 0.10     # Rs. above mother candle high
SL_BUFFER          = 0.10     # Rs. below mother candle low
```

### Add New IPO Stocks

Add symbols to the `RECENT_IPOS` list in `scanner.py`:
```python
RECENT_IPOS = [
    "BAJAJHFL", "SWIGGY", "YOUR_NEW_IPO",  # add here
    ...
]
```

### Change Timing

Edit `.github/workflows/daily_scan.yml`:
```yaml
- cron: '30 16 * * 1-5'   # 10 PM IST = 16:30 UTC, Mon–Fri
```
- 8 PM IST = `'30 14 * * 1-5'`
- 9 AM IST = `'30 3 * * 1-5'`

---

## Free Resources Used

| What | Service | Cost |
|---|---|---|
| Stock data | Yahoo Finance (yfinance) | Free |
| Cloud runner | GitHub Actions | Free (2000 min/month) |
| Mobile alerts | Telegram Bot | Free |
| Code hosting | GitHub | Free |

---

## Troubleshooting

**Telegram not receiving message?**
- Make sure you sent at least one message TO the bot first
- Double-check Token and Chat ID in GitHub Secrets
- Chat ID must be a number (negative for groups, positive for personal)

**Stock shows "no data"?**
- Some newer IPOs may not have full 1-year history on Yahoo Finance yet
- Scanner skips them and continues

**GitHub Actions not running at 10 PM?**
- GitHub cron can delay 5–15 mins during peak load
- Use "Run workflow" button in Actions tab to trigger manually anytime

**Wrong listing date filter?**
- If a stock is incorrectly filtered, yfinance may have wrong IPO date
- Add/remove symbols manually in RECENT_IPOS list as needed
